﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;

namespace EvacProj
{
    public partial class PendingApps : BasePage
    {
        private void GetApplications()
        {
            Applicant applicant = (Applicant)Session["applicant"];
            ExAvDAO exAvDAO = new ExAvDAO(applicant.Username, applicant.Password);
            ApplyDAO applyDAO = new ApplyDAO(applicant.Username, applicant.Password);
            lblName.Text = applicant.FirstName + " " + applicant.LastName;
            lblPendApps.Text = exAvDAO.GetNumberOfExAvApplications().ToString();
            if (applyDAO.GetExAvApplications().Count > 0)
            {
                gvPendingApps.DataSource = applyDAO.GetExAvApplications();
                gvPendingApps.DataBind();
                lblError.Visible = false;
            }
            else
            {
                lblError.Visible = true;
                lblError.Text = "You currently have no applications!";
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetApplications();
            }
        }

        protected void btnApply_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/ExAvApps.aspx");
        }

        protected void gvPendingApps_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Applicant applicant = (Applicant)Session["applicant"];
            ApplicantDAO applicantDAO = new ApplicantDAO(applicant.Username, applicant.Password);
            int index = Convert.ToInt32(e.CommandArgument);
            int ExAvID = Convert.ToInt32(gvPendingApps.Rows[index].Cells[1].Text);
            if (e.CommandName == "WITHDRAW")
            {
                try
                {
                    applicantDAO.WithdrawApplication(ExAvID);
                    GetApplications();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message;
                    lblError.Visible = true;
                }
            }

        }
        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("~/PendingApps.aspx");
        }

        protected void gvPendingApps_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            e.Row.Cells[1].Visible = false;
        }
    }
}